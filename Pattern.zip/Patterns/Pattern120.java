class Pattern120
{
	public static void main(String args[])
	{
		int n= 5;
		int count = ((n*(n+1))/2)-(n-1);
		for(int i=1;i<=n;i++)
		{
			int c = count;
			for(int j=i;j>1;j--)
			{
				System.out.print("\t");
			}
			for(int j=n;j>=i;j--)
			{
				System.out.print(((char)(c+64))+"\t");
				//System.out.print(c+"\t");
				c-=j-1;
			}
			System.out.println();
			count++;
		}
	}
}
/*
output:

K       G       D       B       A
        L       H       E       C
                M       I       F
                        N       J
                                O

*/