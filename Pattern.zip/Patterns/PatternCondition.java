class PatternCondition
{
	public static void main(String args[])
	{
		int n = 10;
		for(int i=1;i<=n;i++)
		{
			int m = i%3;
			if(m==0)	
				System.out.println(0);
			else
				System.out.println(i);
		}
	}
}

/*
output:


1
2
0
4
5
0
7
8
0
10


*/