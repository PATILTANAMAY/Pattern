/*
class Pattern8
{
	public static void main(String args[])
	{	
    int n=5;
    for(int i=1;i<=n;i++){
      for(int j=1;j<=n;j++){
        System.out.print((char)(i+64));
      }
      System.out.println();
    }
	}
	}
 */ 
/*
output:
AAAAA
BBBBB
CCCCC
DDDDD
EEEEE
*/
/*
class Pattern8
{
	public static void main(String args[])
	{	

    for(char i='A';i<='E';i++){
      for(int j=1;j<=5;j++){
        System.out.print(i);
      }
      System.out.println();
    }
	}
	}
*/

class Pattern8
{
	public static void main(String args[])
	{	
    int n=5;
    for(int i=65;i<=69;i++){
      for(int j=1;j<=n;j++){
        System.out.print((char)(i));
      }
      System.out.println();
    }
	}
	}
