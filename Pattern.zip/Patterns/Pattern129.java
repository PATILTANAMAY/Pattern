class Pattern129
{
	public static void main(String args[])
	{
		int n= 5;
		int count1 = n;
		int count2 = 1;
		for(int i=n,l=1;i>=1 && l<=n;i--,l++)
		{
			int c1 = count1;
			int c2 = count2;
			for(int j=i,k=l;j>=1 && k<=n;j--,k++)
			{
				System.out.print((char)(c1+64)+""+(char)(c2+96)+"\t");
				c1--;
				c2+=k;
			}
			System.out.println();
			count1+=i-1;
			count2+=l+1;
		}
	}
}
/*
output:

Ea      Db      Cd      Bg      Ak
Ic      He      Gh      Fl
Lf      Ki      Jm
Nj      Mn
Oo



*/