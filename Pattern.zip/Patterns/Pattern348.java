class Pattern348
{
	public static void main(String args[])
	{
		int n=5;
		for(int i=1;i<=n+2;i++)
		{
			for(int j=1;j<=n*2-1;j++)
			{
				if((i==4) || (i==1) || (i==7) || (i<=4 && j==1) || (j==n && i<=4) || (i==1 && j>=6) || (j==n && i>=5) || (i==7 && j<=4) || (j==9 && i>=4) || (j==9 && i<=4) || (j==1 && i>=4))
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
		
	}
}
/*
output:

*********
*   *   *
*   *   *
*********
*   *   *
*   *   *
*********

*/