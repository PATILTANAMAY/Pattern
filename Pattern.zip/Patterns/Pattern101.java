class Pattern101
{
	public static void main(String args[])
	{
		int n= 5;
		int count = 1;
		for(int i=n;i>=1;i--)
		{
			int c = count;
			for(int j=i;j>1;j--)
			{
				System.out.print("\t");
			}
			for(int j=i;j<=n;j++)
			{
				System.out.print(((char)(c+64))+"\t");
				//System.out.print(c+"\t");
				c-=j;
			}
			System.out.println();
			count+=i;
		}
	}
}
/*
output:
                                A
                        F       B
                J       G       C
        M       K       H       D
O       N       L       I       E

*/