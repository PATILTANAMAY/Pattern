class Pattern39
{
	public static void main(String args[])
	{
		int n=5;
		for(int i=1;i<=n;i++)
		{
			for(int j=i;j<=n;j++ )
			{
				System.out.print((char)(i+96)+ " ");
			}
			System.out.println();
		}
	}
}
/*
output:

A A A A A
B B B B
C C C
D D
E
*/