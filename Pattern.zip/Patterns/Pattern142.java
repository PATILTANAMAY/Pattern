class Pattern142
{
	public static void main(String args[])
	{
		int n=5;
		char c = 'A';
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				if(j%2==1)
					System.out.print(1);
				else
					System.out.print(c++);
			}
			System.out.println();
		}
	}
}
/*
output:
1
1A
1B1
1C1D
1E1F1
*/