class Pattern314
{
	public static void main(String args[])
	{
		int n=5;
		for(int i=n;i>=1;i--)
		{	
			if(i==n)
			{
				for(int j=1;j<=n*2-1;j++)
					System.out.print((char)(i+64));
			}
			else
			{
				for(int j=i;j>=1;j--)
					if(i%2!=1)
						System.out.print((char)(i+96));
					else
						System.out.print((char)(i+64));
				for(int j=1;j<=(n-i+1)*2-3;j++)
					System.out.print(" ");
				for(int j=i;j>=1;j--)
					if(i%2!=1)
						System.out.print((char)(i+96));
					else
						System.out.print((char)(i+64));

			}
			System.out.println();
		}
	}
}
/*
output:

EEEEEEEEE
dddd dddd
CCC   CCC
bb     bb
A       A


*/