
class Pattern9
{
	public static void main(String args[])
	{	
    int n = 5;
    for(int i=n;i>=1;i--){
      for(int j=1;j<=n;j++){
        System.out.print((char)(i+64));
      }
      System.out.println();
    }
	}
	}
 

 /*
output:
EEEEE
DDDDD
CCCCC
BBBBB
AAAAA
*/
/*
class Pattern9
{
	public static void main(String args[])
	{	

    for(char i='E';i>='A';i--){
      for(int j=1;j<=5;j++){
        System.out.print(i);
      }
      System.out.println();
    }
	}
	}

*/
// class Pattern9
// {
// 	public static void main(String args[])
// 	{	
//     for(int i=69;i>=65;i--){
//       for(int j=1;j<=5;j++){
//         System.out.print((char)(i));
//       }
//       System.out.println();
//     }
// 	}
// 	}
