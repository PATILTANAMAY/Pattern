class Pattern29
{
	public static void main(String args[])
	{
		int n=5;
		for(int i=n;i>=1;i--)
		{
			for(int j=i;j<=n;j++)
			{
				System.out.print((char)(j+96)+" ");
			}
			System.out.println();
		}
	}
}

/*
output:
e
d e
c d e
b c d e
a b c d e

*/