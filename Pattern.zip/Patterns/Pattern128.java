class Pattern128
{
	public static void main(String args[])
	{
		int n= 5;
		int count1= (n*(n+1))/2;
		int count2 = 1;
		for(int i=n,l=1 ; i>=1 && l<=n ; i--,l++)
		{
			int c1 = count1;
			int c2 = count2;
			for(int j=i;j>1;j--)
			{
				System.out.print("\t");
			}
			for(int j=i,k=l;j<=n && k>=1;j++,k--)
			{
				System.out.print((char)(c1+64)+""+(char)(c2+64)+"\t");
				c1+=j;
				c2--;
			
			}
			System.out.println();
			count1-=i;
			count2+=l+1;
		}
	}
}
/*
output:

                                OA
                        JC      NB
                FF      IE      MD
        CJ      EI      HH      LG
AO      BN      DM      GL      KK


*/